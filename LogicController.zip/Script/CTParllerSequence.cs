﻿using CTree;
using System;
namespace CTree
{
    public class CTParllerSequence : CTNode                   //并行节点.等待全部执行完毕，全真为真，否则为假.
    {
        private int[] stateCount;
        public CTParllerSequence()
            : base()
        {
            Data._dataName = "ParllerSequence";
            stateCount = new int[(int)NodeState.MAX];
            _nodeType = NodeType.PARALLER_SEQ;
            for (int i = 0; i < stateCount.Length; i++)
            {
                stateCount[i] = 0;
            }
        }
        public CTParllerSequence(string n)
            : base(n)
        {
            stateCount = new int[(int)NodeState.MAX];
            _nodeType = NodeType.PARALLER_SEQ;
            for (int i = 0; i < stateCount.Length; i++)
            {
                stateCount[i] = 0;
            }
        }
        public override void AddNode(CTNode node)
        {
            AddParaller(node);
        }
        public override NodeState Update()
        {
            _nodeState = NodeState.WAITING;
            stateCount[(int)NodeState.WAITING] = 0;
            for (int i = 0; i < _paraller.Count; i++)
            {
                if (_paraller[i]._NodeState == NodeState.WAITING || _paraller[i]._NodeState == NodeState.PREPARE)
                {
                    NodeState nss = _paraller[i].Update();
                    stateCount[(int)nss]++;
                }
            }
            if (stateCount[(int)NodeState.WAITING] > 0)
            {
                _nodeState = NodeState.WAITING;//存在没有执行完的节点
                return _nodeState;
            }
            for (int i = 0; i < stateCount.Length; i++)
            {
                stateCount[i] = 0;
            }
            if (stateCount[(int)NodeState.SUCCESS] == _paraller.Count)
            {
                _nodeState = NodeState.SUCCESS;
                return _nodeState;
            }
            else
            {
                _nodeState = NodeState.FALIER;
                return _nodeState;
            }
        }
    }
}