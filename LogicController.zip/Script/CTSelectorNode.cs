﻿using CTree;
using System;
namespace CTree
{
    public class CTSelectorNode : CTNode           //当执行完一个真节点后返回
    {
        public CTSelectorNode()
            : base()
        {
            _nodeType = NodeType.SELECTOR;
            Data._dataName = "Selector";
        }
        public CTSelectorNode(string n)
            : base(n)
        {
            _nodeType = NodeType.SELECTOR;
        }
        public override NodeState Update()
        {
            NodeState nss = NodeState.WAITING;
            _nodeState = NodeState.WAITING; //等待子节点进行
            for (int i = 0; i < _childs.Count; i++)
            {
                CTNode child = _childs[i];
                if (NodeState.PREPARE == child._NodeState || NodeState.WAITING == child._NodeState)
                {//子节点可以执行
                    nss = child.Update();//执行子节点
                    if (nss == NodeState.SUCCESS) //执行成功，后面的节点不执行
                    {
                        _nodeState = nss;
                        return _nodeState;
                    }
                    else if (nss == NodeState.FALIER) //当前节点子节点执行成功
                    {
                        if (i == _childs.Count - 1) //当前节点时最后一个节点
                        {
                            _nodeState = NodeState.FALIER; //所有节点都失败执行
                            return _nodeState; //所有节点成功执行返回TRUE，否则执行后面的节点
                        }
                    }
                    else if (nss == NodeState.WAITING)
                    {
                        return NodeState.WAITING;
                    }
                }
            }
            //没有要执行的子结点，则直接返回成功
            _nodeState = NodeState.SUCCESS;
            return _nodeState;
        }
    }
}