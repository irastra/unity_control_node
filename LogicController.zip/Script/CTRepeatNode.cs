﻿using CTree;
using System;
namespace CTree
{
    public class CTRepeatNode : CTNode            //重复执行首节点repeatCount次
    {
        public CTRepeatNode()
            : base()
        {
            _nodeType = NodeType.REPEAT;
            Data._dataName = "Repeat";
        }
        public CTRepeatNode(string n)
            : base(n)
        {
            _nodeType = NodeType.REPEAT;
            Data._dataName = "Repeat";
        }
        public override NodeState Update()
        {
            _nodeState = NodeState.WAITING;
            //条件成立
            if (_childs.Count > 0 && _repeatCount > 0)
            {
                _nodeState = _childs[0].Update();
                if (_nodeState == NodeState.WAITING)
                {
                    return NodeState.WAITING;
                }
                else
                {
                    //每个update之多执行一次子节点
                    _repeatCount = _repeatCount - 1;
                    _childs[0].ResetState();
                    _nodeState = NodeState.WAITING;
                    return _nodeState;
                    /* 在一次update中执行完所有的repeat [不科学] 
                    _repeatCount = _repeatCount - 1;
                    _childs[0].ResetState();
                    _nodeState = Update();
                    return _nodeState;
                    */
                }
            }
            _nodeState = NodeState.SUCCESS;
            return _nodeState;
        }
    }
}