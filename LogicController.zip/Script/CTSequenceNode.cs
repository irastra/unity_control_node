﻿using CTree;
using System;
namespace CTree
{
    public class CTSequenceNode : CTNode          //seq序列
    {
        public CTSequenceNode() : base()
        {
            _nodeType = NodeType.SEQUENCE;
            Data._dataName = "Sequence";
        }
        public CTSequenceNode(string n)
            : base(n)
        {
            _nodeType = NodeType.SEQUENCE;
        }
        public override NodeState Update()
        {
            NodeState nss = NodeState.WAITING;
            _nodeState = NodeState.WAITING; //等待子节点进行
            for (int i = 0; i < _childs.Count; i++)
            {
                CTNode child = _childs[i];
                if (NodeState.PREPARE == child._NodeState || NodeState.WAITING == child._NodeState)
                {//子节点可以执行
                    nss = child.Update();//执行子节点
                    if (nss == NodeState.FALIER) //执行失败，后面的节点不执行
                    {
                        _nodeState = nss; //状态设置为失败,并且执行结束
                        return _nodeState;
                    }
                    else if (nss == NodeState.SUCCESS) //当前节点子节点执行成功
                    {
                        if (i == _childs.Count - 1) //当前节点时最后一个节点
                        {
                            _nodeState = NodeState.SUCCESS; //所有节点都成功执行
                            return _nodeState; //所有节点成功执行返回TRUE，否则继续执行.
                        }
                    }
                    else if (nss == NodeState.WAITING)
                    {
                        return NodeState.WAITING;
                    }
                }
            }
            //没有子节点直接返回成功
            _nodeState = NodeState.SUCCESS; //没有子节点直接返回成功
            return _nodeState;
        }
    }
}