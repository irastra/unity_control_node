﻿using CTree;
using System;
using UnityEngine;
namespace CTree
{
    public class WaitMinute : CTNormalNode       //拓展的基础结点.等待五个执行次序.
    {
        float count = 1;
        public WaitMinute(string n) : base(n)
        {
            Data._dataName = "Wait";
        }
        public override NodeState DoAction()
        {
            if (count > 0)
            {
                //Console.WriteLine("Action:" + count);
                count -= 0.01f ;
                if (count > 0)
                {
                    return NodeState.WAITING;
                }
                else
                {
                    return NodeState.SUCCESS;
                }
            }
            return NodeState.SUCCESS;
        }
        protected override void OnReset()
        {
            count = 1;
        }
    }
}