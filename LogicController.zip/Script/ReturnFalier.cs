﻿using CTree;
using System;
namespace CTree
{
    public class ReturnFalier : CTNormalNode
    {
        public ReturnFalier()
            : base()
        {

        }
        public ReturnFalier(string n)
            : base(n)
        {

        }
        public override NodeState DoAction()
        {
            base.DoAction();
            return NodeState.FALIER;
        }
    }
}