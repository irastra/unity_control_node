﻿using CTree;
using System;
namespace CTree
{
    public class ReturnSuccess : CTNormalNode
    {
        public override NodeState DoAction()
        {
            return NodeState.SUCCESS;
        }
    }
}