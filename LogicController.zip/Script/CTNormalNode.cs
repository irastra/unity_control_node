﻿using CTree;
using System;
namespace CTree
{
    public class CTNormalNode : CTNode                       //非结构控制节点，作为拓展节点
    {
        public CTNormalNode()
            : base()
        {
            _nodeType = NodeType.NORMAL;
            Data._dataName = "NormalAction";
        }
        public CTNormalNode(string n)
            : base(n)
        {
            _nodeType = NodeType.NORMAL;
        }
        public override NodeState DoAction()
        {
            _nodeState = base.DoAction();
            return _nodeState;
        }
        public override NodeState Update()
        {
            _nodeState = DoAction();
            return _nodeState;
        }
    }
}