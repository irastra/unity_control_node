﻿using CTree;
using System;
namespace CTree
{
    public class CTParllerSelector : CTNode                  //并行节点等待全部执行完毕全假为假，否则为真.
    {
        private int[] stateCount;
        public CTParllerSelector()
            : base()
        {
            Data._dataName = "ParallelSelector";
            stateCount = new int[(int)NodeState.MAX];
            _nodeType = NodeType.PARALLER_SEL;
            for (int i = 0; i < stateCount.Length; i++)
            {
                stateCount[i] = 0;
            }
        }

        public CTParllerSelector(string n)
            : base(n)
        {
            stateCount = new int[(int)NodeState.MAX];
            _nodeType = NodeType.PARALLER_SEL;
            for (int i = 0; i < stateCount.Length; i++)
            {
                stateCount[i] = 0;
            }
        }
        public override void AddNode(CTNode node)
        {
            AddParaller(node);
        }
        public override NodeState Update()
        {
            _nodeState = NodeState.WAITING;
            stateCount[(int)NodeState.WAITING] = 0;
            for (int i = 0; i < _paraller.Count; i++)
            {
                if (_paraller[i]._NodeState == NodeState.WAITING || _paraller[i]._NodeState == NodeState.PREPARE)
                {
                    NodeState nss = _paraller[i].Update();
                    stateCount[(int)nss]++;
                }
            }
            if (stateCount[(int)NodeState.WAITING] > 0)
            {
                _nodeState = NodeState.WAITING;//存在没有执行完的节点
                return _nodeState;
            }
            for (int i = 0; i < stateCount.Length; i++)
            {
                stateCount[i] = 0;
            }
            if (stateCount[(int)NodeState.FALIER] == _paraller.Count)
            {
                _nodeState = NodeState.FALIER;
                return _nodeState;
            }
            else
            {
                _nodeState = NodeState.SUCCESS;
                return _nodeState;
            }
        }
    }
}