﻿using CTree;
using System;
namespace CTree
{
    public class RandomNode : CTNode              //在子节点中随机选择执行节点.
    {
        int idx = 0;
        public RandomNode()
            : base()
        {
            _nodeType = NodeType.RANDOMNODE;
            Data._dataName = "Random";
        }

        public RandomNode(string n)
            : base(n)
        {
            _nodeType = NodeType.RANDOMNODE;
        }

        public override NodeState Update()
        {
            if (_childs.Count <= 0)
            {
                return NodeState.SUCCESS; //没有子节点，直接返回成功.
            }
            //存在子节点.

            if (_nodeState == NodeState.PREPARE)
            {
                idx = _childs.Count - 1; // !!! 请在具体的应用下换成对应的随机数.
                _nodeState = _childs[idx].Update();
                return _nodeState;
            }
            else if (_nodeState == NodeState.WAITING)
            {
                //之前节点的
                _nodeState = _childs[idx].Update();
                return _nodeState;
            }
            return NodeState.SUCCESS; //返回执行成功.
        }
    }
}