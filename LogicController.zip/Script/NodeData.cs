﻿using CTree;
using System;
using UnityEditor;
namespace CTree
{
    public class NodeDate
    {
        public string _dataName;
        public float _ScreenPosX;
        public NodeDate(string name)
        {
            _dataName = name;
            _ScreenPosX = 0;
        }
        public void ShowData()
        {
            Console.WriteLine(_dataName);
        }
    }
}