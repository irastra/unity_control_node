﻿using System;
using System.Collections.Generic;
using System.Collections;
using CTree;
namespace CTree
{
    public enum NodeType
    {
        NORMAL = 1,             //动作节点
        SEQUENCE = 2,           //序列节点
        SELECTOR = 3,           //重复节点
        REPEAT = 4,             //选择节点
        PARALLER_SEL = 5,       //并行选择
        PARALLER_SEQ = 6,       //并行序列
        RANDOMNODE = 7        //在子节点中随机选择一个节点
    }
    public enum NodeState
    {
        SUCCESS = 1,           //成功状态
        FALIER = 2,           //失败状态
        WAITING = 3,           //等待状态
        ERROR = 4,            //错误状态
        PREPARE = 5,           //准备状态
        MAX = 6                //最大状态个数
    }
    public class CTNode
    {
        public CTNode _parent = null;
        public List<CTNode> _paraller = null;              //并行节点
        public List<CTNode> _childs = null;                //子节点
        protected NodeDate _data = null;                     //数据节点
        protected NodeType _nodeType = NodeType.NORMAL;      //默认节点类型为正常类型.
        protected NodeState _nodeState = NodeState.PREPARE;  //默认节点可执行节点
        public int _repeatCount = 0;                       //重复节点专有
        public NodeState _NodeState { get { return _nodeState; } }
        public NodeType _NodeType { get { return _nodeType; } set { _nodeType = value; } }
        public NodeDate Data { set { _data = value; } get { return _data; } }
        public int ChildCount { get { return _childs.Count; } }
        public List<CTNode> Child { get { return _childs; } }
        public CTNode()
        {
            _childs = new List<CTNode>();
            _paraller = new List<CTNode>();
            _data = new NodeDate("");
            _nodeState = NodeState.PREPARE;
            _nodeType = NodeType.NORMAL;
        }
        public CTNode(string name)
        {
            _childs = new List<CTNode>();
            _paraller = new List<CTNode>();
            _data = new NodeDate(name);
            _nodeState = NodeState.PREPARE;
            _nodeType = NodeType.NORMAL;
        }

        public void AddParaller(CTNode node) //添加并行结构
        {
            if (_nodeType == NodeType.PARALLER_SEL || _nodeType == NodeType.PARALLER_SEQ)
            {//可以添加并行节点
                _paraller.Add(node);
                node._parent = this;
            }
        }
        public virtual void AddNode(CTNode node) //添加子结构
        {
            if (null == node)
            {
                return;
            }
            _childs.Add(node);
            node._parent = this;
        }
        public void RemoveFromParent()
        {
            if (null != _parent)
            {
                if (null != _parent._childs)
                {
                    _parent._childs.Remove(this);
                }
                if (null != _parent._paraller)
                {
                    _parent._paraller.Remove(this);
                }
                _parent = null;
            }
        }
        public void PreOrderVisit() //遍历单一控制流，不包含并行
        {
            _data.ShowData();
            for (int i = 0; i < _childs.Count; i++)
            {
                CTNode tNode = _childs[i];
                tNode.PreOrderVisit();
            }
        }
        public void PreOrderVisitParaller() //遍历单一控制流，包含并行
        {
            _data.ShowData();
            for (int i = 0; i < _childs.Count; i++)
            {
                CTNode tNode = _childs[i];
                tNode.PreOrderVisitParaller();
            }
            for (int i = 0; i < _paraller.Count; i++)
            {
                CTNode tNode = _paraller[i];
                tNode.PreOrderVisitParaller();
            }
        }

        public virtual NodeState DoAction() //执行节点
        {
            _data.ShowData();
            _nodeState = NodeState.SUCCESS;
            return _nodeState;
        }
        protected virtual void OnReset()
        {

        }
        public void ResetState()  //子结构需要重新执行的能力时进行执行
        {
            _nodeState = NodeState.PREPARE;
            OnReset();
            for (int i = 0; i < _childs.Count; i++)
            {
                _childs[i].ResetState();
            }
            for (int i = 0; i < _paraller.Count; i++)
            {
                _paraller[i].ResetState();
            }
        }

        public void _Start() //生命周期Start的时候请执行
        {
            OnStart();
            for (int i = 0; i < _childs.Count; i++)
            {
                _childs[i]._Start();
            }
            for (int i = 0; i < _paraller.Count; i++)
            {
                _paraller[i]._Start();
            }
        }
        public virtual void OnStart()
        {

        }

        public void _End() //生命周期End的时候请执行
        {
            OnEnd();
            for (int i = 0; i < _childs.Count; i++)
            {
                _childs[i]._Start();
            }
            for (int i = 0; i < _paraller.Count; i++)
            {
                _paraller[i]._Start();
            }
        }
        public virtual void OnEnd()
        {

        }
        public virtual NodeState Update() //生命周期Update的时候请执行
        {
            return NodeState.SUCCESS;
        }
    }
    class CTree
    {
        public CTNode _start = null;
        public string name; //名称
        public CTree()
        {

        }
        public CTree(CTNode startNode, string tName)
        {
            _start = startNode;
            name = tName;
        }
        public void OnUpdate()
        {
            if (null == _start)
            {
                Console.WriteLine("Error state null start node!");
            }
            NodeState nss = _start._NodeState;
            switch (nss)
            {
                case NodeState.PREPARE:
                case NodeState.WAITING:
                    nss = _start.Update();
                    break;
                default:
                    nss = NodeState.ERROR;
                    break;
            }
            switch (nss)
            {
                case NodeState.SUCCESS:
                case NodeState.FALIER:
                    OnComplete(); //执行完毕
                    break;
            }
        }
        public void OnComplete()
        {
            if (null != _start)
            {
                _start.ResetState();
            }
        }
    }

}
namespace ConsoleApplication7
{
    class Program
    {
        static void Main(string[] args)
        {
            CTNode[] nodes = new CTNode[10];
            nodes[0] = new CTParllerSequence("0");
            nodes[1] = new WaitMinute("1");
            nodes[2] = new CTSelectorNode("2");
            nodes[3] = new CTNormalNode("3");
            nodes[8] = new CTRepeatNode("8");
            nodes[8]._repeatCount = 3;
            nodes[8].AddNode(nodes[2]);
            nodes[0].AddParaller(nodes[1]);
            nodes[0].AddParaller(nodes[8]);
            nodes[0].AddParaller(nodes[3]);
            //nodes[4] = new CTNormalNode("4");
            nodes[4] = new ReturnFalier("4");
            nodes[5] = new CTNormalNode("5");
            //nodes[5] = new ReturnFalier("5");
            nodes[6] = new CTNormalNode("6");
            nodes[2].AddNode(nodes[4]);
            nodes[2].AddNode(nodes[5]);
            nodes[2].AddNode(nodes[6]);
            NodeState nss = NodeState.WAITING;
            do
            {
                nss = nodes[0].Update();
                Console.WriteLine("fin!");
            }
            while (nss == NodeState.WAITING);  //状态为waiting则说明存在没有执行完毕的节点.
        }
    }
}
