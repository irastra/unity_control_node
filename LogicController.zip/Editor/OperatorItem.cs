﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using CTEdtorSp;
using CTree;
using UnityEditor;
namespace CTEdtorSp
{
    //具有拖动的色块
    public class OperatorItem : DisplayItemBase
    {
        public bool isDownSel = false;
        public bool isRightSel = false;
        public List<OperatorItem> _childItems;//与其相关联的孩子节点.
        public OperatorItem _fatherItem;//父节点.
        public Vector2 half;
        public Rect strPos;
        public Rect strNamePos;
        public Vector2 cOffset;
        public CTNode cNode;           //节点.

        public OperatorItem()
        {
            half = new Vector2(_rect.width / 2, _rect.height / 2);
            _childItems = new List<OperatorItem>();

        }
        public OperatorItem(Vector2 pos, float w, float h)
            : base(pos, w, h)
        {
            half = new Vector2(_rect.width / 2, _rect.height / 2);
            _childItems = new List<OperatorItem>();
        }
        public bool InRange(Vector2 pos)
        {
            return (pos.x >= _rect.x && pos.x <= _rect.x + _rect.width && pos.y >= _rect.y && pos.y < _rect.y + _rect.height);
        }
        public void OnDraw()
        {
            for (int i = 0; i < _childItems.Count; i++)
            {
                OperatorItem _childItem = _childItems[i];
                //绘制与子节点的链接
                if (null != _childItem)
                {
                    CTEditor.DrawLine(Pos + half, _childItem.Pos + _childItem.half);
                }
            }

            //绘制当节点自身样子
            DrawSelf();
        }
        private void DrawSelf()
        {
            if (!isDownSel && !isRightSel)
            {
                switch (cNode._NodeState)
                {
                    case NodeState.PREPARE:
                        _curColor = _colors[0];
                        break;
                    case NodeState.WAITING:
                        _curColor = _colors[3];
                        break;
                    case NodeState.SUCCESS:
                        _curColor = _colors[4];
                        break;
                    case NodeState.FALIER:
                        _curColor = _colors[5];
                        break;
                    case NodeState.ERROR:
                        _curColor = _colors[6];
                        break;
                    default:
                        break;
                }
            }
            EditorGUI.DrawRect(_rect, _curColor);
            strPos = _rect;
            strNamePos = _rect;
            strNamePos.y += 20;
            //strPos.position = _rect.position + half;
            EditorGUI.LabelField(strPos, cNode._NodeType.ToString());
            EditorGUI.LabelField(strNamePos, cNode.Data._dataName);
        }
        //添加一个子节点
        public void RemoveFromParent()
        {
            if (null != _fatherItem)
            {
                _fatherItem._childItems.Remove(this);
                _fatherItem = null;
            }
        }
        bool IsFather(OperatorItem item)
        {
            if (null != item)
            {
                if (item == this)
                {
                    return true;
                }
                if (null != _fatherItem)
                {
                    if (_fatherItem == item)
                    {
                        return true;
                    }
                    else
                    {
                        return _fatherItem.IsFather(item);
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        public void SetChild(OperatorItem item)
        {
            if (null == item)
            {
                return;
            }
            if (IsFather(item)) //是直接或者间接父节点或本身
            {
                return;
            }
            if (cNode._NodeType == NodeType.NORMAL || (cNode._NodeType == NodeType.REPEAT && cNode.ChildCount > 1))
            {
                return;
            }
            item.RemoveFromParent();
            _childItems.Add(item);
            item._fatherItem = this;
            item.cNode.RemoveFromParent();
            if (cNode._NodeType == NodeType.REPEAT)
            {
                if (cNode.ChildCount > 0)
                {
                    cNode.Child[0].RemoveFromParent();
                    _childItems[0].RemoveFromParent();
                }
            }
            cNode.AddNode(item.cNode);
        }

    }
}
