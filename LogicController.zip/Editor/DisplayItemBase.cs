﻿using UnityEngine;
using System.Collections;
namespace CTEdtorSp
{
    //基本色块
    public class DisplayItemBase
    {
        public Rect _rect = new Rect();
        public Color[] _colors = new Color[] { Color.white, Color.green, Color.red, Color.cyan, Color.cyan };
        public string name;
        public Vector2 Pos { set { _rect.position = value; } get { return _rect.position; } }
        public Color _curColor = Color.green;
        public DisplayItemBase()
        {
        }
        public DisplayItemBase(Vector2 pos, float w, float h)
        {
            Pos = pos;
            _rect.width = w;
            _rect.height = h;
        }
    }
}
